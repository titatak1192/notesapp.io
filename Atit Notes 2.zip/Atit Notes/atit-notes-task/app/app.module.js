(function(){
    'use strict';

    angular.module('notes', [])
        .constant('NOTE_AUTO_SAVE_TIME', 1000)
        .constant('API_BASE_DOMAIN', 'https://broken-thunder-7744.getsandbox.com/');

}());